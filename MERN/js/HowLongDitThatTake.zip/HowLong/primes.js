const { performance } = require('perf_hooks');

Number.prototype.isPrime1 = function() {
    for( let i=2; i<this; i++ ) {
        if( this % i === 0 ) {
            return false;
        }
    }
    return true;
}

Number.prototype.isPrime2 = function() {
    for( let i=2; i<= Math.sqrt(this); i++){
        if( this % i === 0){
            return false;
        }
    }
    return true;
}

// let num = 28_391_849;
// console.log(num.isPrime2());
// console.log(num.isPrime1());

findNthPrime = function(nth){
    let primeCount = 1;
    let num = 3;
    while( primeCount < nth/*1_000_000*/ ) {
        if( num.isPrime2() ) {
            primeCount++;
        }
        num += 2;
    }
    return num-2;
}
const start = performance.now();
console.log(`The 1,000,000th prime number is ${findNthPrime(1_000_000)}`);
console.log(`This took ${performance.now() - start} milliseconds to run`);
 

// const start = performance.now();
// let primeCount = 0;
// let num = 2;
// while( primeCount < 100_000 ) {
//     if( num.isPrime2() ) {
//         primeCount++;
//     }
//     num++;
// }