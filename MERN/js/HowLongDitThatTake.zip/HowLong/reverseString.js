//
// Efficient way to reverse a strig with only one for loop
//
String.prototype.reverse = function reverse(){
    let a = Array.from(this);
    let temp;
    for(i=0; i< this.length/2; ++i){
        temp = a[i];
        a[i] = a[this.length-1-i];
        a[this.length-1-i] = temp;
    }
    return a.join("");
}



const story = "Lorem ipsum dolor sit amety!";
const reversed1 = story.split("").reverse().join("");
// const reversed2 = story.


console.log(`1: ${reversed1}`);
// console.log(`2: ${reverse(story)}`);
console.log(`2: ${story.reverse()}`);