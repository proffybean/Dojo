
The 100,000th prime is: 1,299,709
The 1,000,000th prime is: 15,485,863

The iterative Fibonacci algorithm is faster.