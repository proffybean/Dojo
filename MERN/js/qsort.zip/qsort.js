function sort(A){
    quickSort(A, 0, A.length - 1);
    return A;
}

function quickSort(A, left, right){
    if (A.length == 1) return;
    if (right - left <= 1) return;

    let p = partition(A, left, right);
    quickSort(A, left, p-1);
    quickSort(A, p, right);
}

function partition(A, left, right){
    let p = right;
    let pivot = A[p];
    let temp;
    
    for (let i = left; i < p; i++){
        while (A[i] > pivot){
            if (Math.abs(p - i) <= 1){
                temp = A[p];
                A[p] = A[i];
                A[i] = temp;
            } else {
                temp = A[p - 1];
                A[p - 1] = A[p];
                A[p] = A[i];
                A[i] = temp;
            }
            p--;
        }
    }
    return p;
}

myArray = [1, 5, 4, 3]
console.log(myArray);
sort(myArray)
console.log('sorted array: '+ myArray);