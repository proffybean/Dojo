import React, {useEffect, useState} from 'react';
import axios from 'axios';
import './App.css';

function App() {

  const [name, setName] = useState("")
  const [names, setNames] = useState([])
  const [pokemonNum, setPokemonNum] = useState(1)

  useEffect(()=>{
    if (pokemonNum < 807){
      axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemonNum}`)
      .then( (res) => {
        // console.log(res)
        // console.log(res.data)
        // console.log(`name: %{res.data.forms[0].name}`)
        setName(res.data.forms[0].name)
        setNames([ ...names, res.data.forms[0].name])
      })
      .catch( (err) => console.log(err))

      setPokemonNum(pokemonNum+1)
    }
  }, [names])


  return (
    <div className="App">
      <div className="container">
        <ol>
          {
            names.map( (pokemon, index) => {
              return (
                <li key={index}>{pokemon}</li>
              )
            })
          }
        </ol>
      </div>
    </div>
  );
}

export default App;
