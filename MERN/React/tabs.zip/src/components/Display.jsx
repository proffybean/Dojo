import React from "react";

const Display = props => {

    const {content} = props

    return (
        <div className="display">
            {content}
        </div>
    )
}
export default Display