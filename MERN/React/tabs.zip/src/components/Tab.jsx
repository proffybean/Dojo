import React from "react";

const Tab = props => {

    const {tabsInfo, activeTab, setActiveTab} = props

    const setTabClass = (index) =>{
        return (index === activeTab) ? 'activeTab' : 'inactiveTab' 
    }

    return (
        <div className="tabs">
            {
                tabsInfo.map( (tab, index) => (
                    <p onClick={ 
                        () => setActiveTab(index)} 
                        className={`${setTabClass(index)} tab`}>
                        {tab.label}
                    </p>
                ))
            }
        </div>
    )
}
export default Tab