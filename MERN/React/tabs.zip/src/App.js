import Tab from './components/Tab';
import Display from './components/Display';
import './App.css';
import React, {useState} from 'react'

function App() {

  const tabsInfo =[
    {
      label: 'Tab 1',
      content: 'first tab content'
    },
    {
      label: 'Tab 2',
      content: 'second tab content'
    },
    {
      label: 'Tab 3',
      content: 'third tab content'
    }
  ]
  // todo use enum here for tab number?
  const [activeTab, setActiveTab] = useState(0)

  return (
    <div className="App">
      <Tab tabsInfo={tabsInfo} activeTab={activeTab} setActiveTab={setActiveTab}/>
      <Display content={tabsInfo[activeTab].content}/>
    </div>
  )
}
export default App;
