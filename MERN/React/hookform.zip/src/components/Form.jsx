import React, {useState} from "react";

const Form = props => {

    const [firstName, setFirstName] = useState("")
    const [lastName, setLastName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [cpassword, setcPassword] = useState("")

    return (
        <div>
            <form>
                <div className="dataEntry">
                    <label>First Name: </label>
                    <input type="text" 
                        onChange={ e => {
                            console.log(e.target.value);
                            setFirstName(e.target.value);
                        }}
                    />
                </div>

                <div className="dataEntry">
                    <label>Last Name: </label>
                    <input type="text" onChange={ e => {
                        console.log(e.target.value)
                        setLastName(e.target.value)
                    }}/>
                </div>

                <div className="dataEntry">
                    <label>Email: </label>
                    <input type="text" onChange={ e => {
                        console.log(e.target.value)
                        setEmail(e.target.value)
                    }}/>
                </div>

                <div className="dataEntry">
                    <label>Password: </label>
                    <input type="password" onChange={ e => {
                        setPassword(e.target.value)
                    }}
                    />
                </div>

                <div className="dataEntry">
                    <label>Confirm Password: </label>
                    <input type="password" onChange={ e => {
                        setcPassword(e.target.value)
                    }}/>
                </div>
            </form>

            <div>
                <h3>Your Form Data</h3>
                <p>FirstName: {firstName}</p>
                <p>LastName: {lastName}</p>
                <p>email: {email}</p>
                <p>password: {password}</p>
                <p>confirm password: {cpassword}</p>
            </div>

        </div>
    )

}
export default Form