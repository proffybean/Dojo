import Home from './Components/Home';
import Num from './Components/Num';
import './App.css';
import {BrowserRouter, Routes, Route} from 'react-router-dom'

function App() {
  return (

    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/:num" element={<Num />}/>
          <Route path="/:num/:color1/:color2" element={<Num />}/>
        </Routes>
      </div>
    </BrowserRouter>

  );
}

export default App;
