import React from "react";
import {useParams} from 'react-router-dom'

const Num = (props) =>{

    const {num, color1, color2} = useParams();


    return(
        <div>
            {
                ({color1} && {color2})? 
                <h1 style={{color:color1, backgroundColor:color2}}>The word is {num}</h1>
                : isNaN(num)?
                    <h1>The word is: {num}</h1>
                    :<h1>The number is: {num}</h1>
            }
        </div>
    )
}
export default Num