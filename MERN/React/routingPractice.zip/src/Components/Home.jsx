import React from "react";
import {Link} from 'react-router-dom'

const Home = (props) =>{

    return(
        <div>
            <h2>Welcome</h2>
        </div>
    )
}
export default Home