import React, {useState} from "react";

const Form = (props) => {

    const { boxlist, setBoxlist} = props
    const [ color, setColor ] = useState("")

    const addBox = (e) => {
        e.preventDefault()
        // console.log(e.target)
        // console.log('hello')
        // console.log(...boxlist)
        //setBoxlist((boxlist) => [...boxlist, color])
        setBoxlist([ ...boxlist, color])
        setColor("")
    }

    return (
        <div>
            <div>
                <form onSubmit={addBox}>
                    <label>Color</label>
                    <input type="text" onChange={ e => {setColor(e.target.value)}} value={color}></input>
                    <button>Add</button>
                </form>
            </div>
        </div>
    )
}
export default Form