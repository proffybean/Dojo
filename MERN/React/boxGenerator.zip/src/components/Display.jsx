import React from "react";

const Display = (props) => {
    const { boxlist}= props

    return (
        <div className="boxBody">
            {
                boxlist.map( (boxColor, index) => {
                    return (
                        <div key={index} style={{backgroundColor:boxColor}} className="box">
                        </div>
                    )
                })
            }
        </div>
    )
}
export default Display