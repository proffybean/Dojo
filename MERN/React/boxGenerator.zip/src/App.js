import Display from './components/Display';
import Form from './components/Form';
import {useState} from "react"
import './App.css';

function App() {

  const [ boxlist, setBoxlist] = useState([])

  return (
    <div className="App">
      <Form boxlist={boxlist} setBoxlist={setBoxlist}/>
      <Display boxlist={boxlist}/>
    </div>
  );
}

export default App;
