import React, {useState} from "react";

const PersonCard = (props) => {

    const {firstName, lastName, age, hair} = props;
    const [ years, setYears ]= useState(age);

    return (
        <div>
            <div className="card">
                <h3>{lastName}, {firstName}</h3>
                <p>Age: {years}</p>
                <p>Hair Color: {hair}</p>
                <button onClick={ event => setYears(years + 1) }>
                    Birthday Button for {firstName} {lastName}</button>
            </div>
        </div>
    )
}
export default PersonCard;