import React, {useState} from "react";
// import Todo from "./Todo";

const Display = (props) => {

    const {todoList, setTodoList} = props

    const handleCompleted = (e,todo) =>{
        console.log(e)
        console.log(e.target)
        todo.complete = e.target.checked? true : false
        setTodoList([...todoList])
    }

    const deleteButton = (id) =>{
        console.log(`deleting ${id}`)
        setTodoList( todoList.filter( (todo, index) => todo.id !== id) )
    }

    const setTodoClass = (i) => {
        return ( i.complete ) ? 'completedTodo': 'uncompletedTodo'
    }

    return (
        <div>
            {
                todoList.map( (todo, index) => {
                    return (
                        <div key={index}>
                            <p className={setTodoClass(todo)}>
                                {todo.item}
                                <input type="checkbox" onClick={ (e) => handleCompleted(e,todo)} />
                                <button onClick={ () => deleteButton(todo.id) }>Delete</button>
                            </p>
                        </div>
                    )
                })
            }
        </div>
    )
}
export default Display