import React, {useState} from "react";

const Todo = props => {

    const {todo, setTodo, todoList, setTodoList} = props;
    const [task, setTask] = useState('')

    const handleSubmit = (e) => {

        const newTodo = {
            item:task, 
            complete:false,
            id: Math.floor(Math.random()*10000).toString()
        }

        e.preventDefault()
        console.log('handling...')
        setTodoList([...todoList, newTodo])
        setTask('')
    }

    const setTodo1 = (e) => {
        setTodo({item:e.target.value, complete:false})
    }

    return (
        <div>
            <form onSubmit={ (e) => handleSubmit(e)}>
                <label>Add Todo:</label>
                <input type="text" onChange={ (e) => setTask(e.target.value)} value={task}></input>
            </form>
        </div>
    )
}
export default Todo