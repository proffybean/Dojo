import React, {useState} from "react";
import Todo from "./components/Todo";
import Display from "./components/Display";
import './App.css';

function App() {

  const [todo, setTodo] = useState({})
  const [todoList, setTodoList] = useState([])

  return (
    <div className="App">
      <Todo todo={todo} setTodo={setTodo} todoList={todoList} setTodoList={setTodoList}/>
      <Display todoList={todoList} setTodoList={setTodoList}/>
    </div>
  );
}

export default App;
