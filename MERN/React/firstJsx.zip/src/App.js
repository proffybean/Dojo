
import './App.css';
import Homepage from './components/Homepage';
import Todo from './components/Todo';

function App() {
  return (
    <div className="App">
      <Homepage font="big"/>
      <Todo font="medium" listStyle="todo"/>
    </div>
  );
}

export default App;
