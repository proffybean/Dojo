import React from "react";

const Homepage = (props) => {

    const {font} = props;

    return (
        <div>
            <h1 className={font}>Hello Dojo!</h1>
        </div>
    )
}
export default Homepage;