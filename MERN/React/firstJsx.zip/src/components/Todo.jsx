import React from "react";

const Todo = (props) => {

    const {font, listStyle} = props;

    return (
        <div>
            <h3 className={font}>Things I need to do:</h3>
            <ul className={listStyle}>
                <li>Learn React</li>
                <li>Climb Mt. Everest</li>
                <li>Run a marathon</li>
                <li>Feed the dog</li>
            </ul>
        </div>
    )
}
export default Todo;