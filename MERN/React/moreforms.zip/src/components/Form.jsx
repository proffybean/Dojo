import React, {useState} from "react";

const Form = props => {

    const [firstName, setFirstName] = useState("")
    const [firstNameError, setFirstNameError] = useState("")

    const [lastName, setLastName] = useState("")
    const [lastNameError, setLastNameError] = useState("")

    const [email, setEmail] = useState("")
    const [emailError, setEmailError] = useState("")

    const [password, setPassword] = useState("")
    const [cpassword, setcPassword] = useState("")
    const [passwordError, setPasswordError] = useState("")
    const [cpasswordError, setcPasswordError] = useState("")

    const handlePassword = (e, other) => {
        setPassword(e.target.value)

        if (e.target.value.length === 0){
            setPasswordError('Password is required')
        } else if (e.target.value.length < 8) {
            setPasswordError('Password must be at least 8 chars')
        } else {
            setPasswordError(null)
        }

        if (e.target.value === other){
            setcPasswordError(null)
        } else {
            setcPasswordError('Passwords do not match')
        }
    }

    const handleCPassword = (e, other) => {
        setcPassword(e.target.value)

        console.log('cpassword: ' + e.target.value)
        console.log('password: ' + other)

        if ( e.target.value === other){
            setcPasswordError(null)
        } else {
            setcPasswordError('Passwords do not match')
        }
    }

    const handleFirstName = (e) => {
        setFirstName(e.target.value)

        if(e.target.value.length === 0){
            setFirstNameError('First name is required')
        } else if (e.target.value.length < 2) {
            setFirstNameError('First name must be at least 2 chars')
        } else {
            setFirstNameError(null)
        }
    }

    const handleLastName = (e) => {
        setLastName(e.target.value)
        
        if(e.target.value.length === 0){ // why not check lastName here with a getter?
            setLastNameError('Last name is required')
        } else if( e.target.value.length < 2 ){
            setLastNameError('Last name must be at least 2 chars')
        } else {
            setLastNameError(null)
        }
    }

    const handleEmail = (e) => {
        setEmail(e.target.value)

        if(e.target.value.length === 0){
            setEmailError('Email is required')
        } else if ( e.target.value.length < 5){
            setEmailError('Email must be at least 5 chars')
        } else {
            setEmailError(null)
        }
    }

    return (
        <div>
            <form>
                <div className="dataEntry">
                    <label>First Name: </label>
                    <input type="text" 
                        onChange={ e => {
                            console.log(e.target.value);
                            handleFirstName(e)
                        }}
                    />
                    {
                        firstNameError ?
                        <p className="inputError">{firstNameError}</p>
                        : null
                    }
                </div>

                <div className="dataEntry">
                    <label>Last Name: </label>
                    <input type="text" onChange={ e => {
                        console.log(e.target.value)
                        handleLastName(e)
                    }}/>
                    {
                        lastNameError ?
                        <p className="inputError">{lastNameError}</p>
                        : null
                    }
                </div>

                <div className="dataEntry">
                    <label>Email: </label>
                    <input type="text" onChange={ e => {
                        console.log(e.target.value)
                        handleEmail(e)
                    }}/>
                    {
                        emailError ?
                        <p className="inputError">{emailError}</p>
                        : null
                    }
                </div>

                <div className="dataEntry">
                    <label>Password: </label>
                    <input type="password" onChange={ e => {
                        handlePassword(e, cpassword)
                    }}/>
                    {
                        passwordError
                        ? <p className="inputError">{passwordError}</p>
                        : null
                    }
                    {
                        cpasswordError
                        ? <p className="inputError">{cpasswordError}</p>
                        : null
                    }
                </div>

                <div className="dataEntry">
                    <label>Confirm Password: </label>
                    <input type="password" onChange={ e => {
                        handleCPassword(e, password)
                    }}/>
                    {
                        passwordError
                        ? <p className="inputError">{passwordError}</p>
                        : null
                    }
                    {
                        cpasswordError
                        ? <p className="inputError">{cpasswordError}</p>
                        : null
                    }
                </div>
            </form>
        </div>
    )
}
export default Form