let total = 0;
for(let a = 0; a <=100; a++){
    total += a;
}
console.log(total);