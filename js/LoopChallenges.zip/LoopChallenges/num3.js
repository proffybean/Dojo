var arr = [4, 2.5, 1, -.5, -2, -3.5];
arr.forEach( el => console.log(el));