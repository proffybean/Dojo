var product = 1;
for(var i=2; i<=12; i++){
    product = product * i;
}
console.log(product);