let i = 100
while (i >= 0) {
    if(i%3 == 0){
        console.log(i);
    }
    i--;
}