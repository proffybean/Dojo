function loginClicked(el){
    el.innerText = 'Logout'; 
}
function DefClicked(el){
    el.remove();
}
function likeClicked(){
    alert('Ninja was liked');
}