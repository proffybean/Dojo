console.log("page loaded...");

function editProfile(){
    var name = document.querySelector('.card-body h1');
    name.innerText = 'Lil\' Cricket';
}

function removeRequest(item){
    var requestCon = document.querySelector('li#item' + item);
    requestCon.remove();

    decreaseConnectionNum();
}

function acceptRequest(item){
    var requestCon = document.querySelector('li#item' + item);
    requestCon.remove();

    decreaseConnectionNum();
    increaseConnections();
}

function decreaseConnectionNum(){
    let numConnections = document.querySelector('.card .badge');
    let num = parseInt(numConnections.innerText);

    numConnections.innerText = --num;
}

function increaseConnections(){
    let urConnectionsNode = document.querySelector('#urConnBadge');
    let num = parseInt(urConnectionsNode.innerText);

    urConnectionsNode.innerText = ++num;
}