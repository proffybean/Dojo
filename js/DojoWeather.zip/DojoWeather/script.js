function loadWeather(el){
    alert("Loading weather report for " + el.innerText);
}

function acceptCookie(el){
    alertCookie = document.querySelector('.cookie-alert');
    alertCookie.remove();
}

function changeTempUnits(el){
    changeToUnits = el.value.toString();
    changeTempFor(changeToUnits, document.querySelector('.col1 .high .value'));
    changeTempFor(changeToUnits, document.querySelector('.col1 .low .value'));
    changeTempFor(changeToUnits, document.querySelector('.col2 .high .value'));
    changeTempFor(changeToUnits, document.querySelector('.col2 .low .value'));
    changeTempFor(changeToUnits, document.querySelector('.col3 .high .value'));
    changeTempFor(changeToUnits, document.querySelector('.col3 .low .value'));
    changeTempFor(changeToUnits, document.querySelector('.col4 .high .value'));
    changeTempFor(changeToUnits, document.querySelector('.col4 .low .value'));
}

function changeTempFor(changeToUnits, tempOnWeatherCard){
    console.log('change to units ' + changeToUnits);
    var temperature = parseInt(tempOnWeatherCard.innerText);
    console.log('current temp ' + temperature);
    var convertedTemp;

    if(changeToUnits.includes('F')){
        console.log("im Ferhrenheit");
        convertedTemp = convertTempCtoF(temperature);
    }else{
        console.log("im celcius");
        convertedTemp = convertTempFtoC(temperature);
    }

    tempOnWeatherCard.innerText = convertedTemp;
}

function convertTempFtoC(temp){
    return Math.round((temp-32) * 5/9);
}

function convertTempCtoF(temp){
    return Math.round((temp*9/5) + 32);
}