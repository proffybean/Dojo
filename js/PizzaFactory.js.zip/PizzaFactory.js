function pizzaOven(crustType, sauceType, cheeses, toppings){
    var pizza = {};
    pizza.crustType = crustType;
    pizza.sauceType = sauceType;
    pizza.cheeses = cheeses;
    pizza.toppings = toppings;

    return pizza;
}

let myPizza = pizzaOven(
    'deep dish', 
    'traditional', 
    ['mozzarella'],
    ['pepperoni', 'sausage']);
console.log(myPizza);

let myPizza2 = pizzaOven(
    "hand tossed", 
    "marinara", 
    ["mozzarella", "feta"],
    ["mushrooms", "olives", "onions"]
);
console.log(myPizza2);

let myPizza3 = pizzaOven(
    "thin", 
    "marinara", 
    ["mozzarella", "cheddar"],
    ["chicken", "olives"]
);
console.log(myPizza3);

let myPizza4 = pizzaOven(
    "gluten free", 
    "marinara", 
    ["mozzarella"],
    ["green peppers", "mushrooms"]
);
console.log(myPizza4);