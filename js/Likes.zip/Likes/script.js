function likeClicked(){
    el = document.querySelector('#numLikes');
    var numLikes = parseInt(el.innerText);
    el.innerText = ++numLikes;
}

function likeClickedEx(id){
    el = document.querySelector('#' + id);
    var numLikes = parseInt(el.innerText);
    el.innerText = ++numLikes;
}